module modernc.org/libc

go 1.24.0

retract v1.43.0

retract v1.67.5

require (
	github.com/dustin/go-humanize v1.0.1
	github.com/google/uuid v1.6.0
	github.com/mattn/go-isatty v0.0.20
	github.com/ncruces/go-strftime v1.0.0
	golang.org/x/sys v0.41.0
	golang.org/x/tools v0.42.0
	modernc.org/cc/v4 v4.27.1
	modernc.org/ccgo/v4 v4.32.0
	modernc.org/fileutil v1.4.0
	modernc.org/goabi0 v0.2.0
	modernc.org/mathutil v1.7.1
	modernc.org/memory v1.11.0
)

require (
	github.com/hashicorp/golang-lru/v2 v2.0.7 // indirect
	github.com/remyoudompheng/bigfft v0.0.0-20230129092748-24d4a6f8daec // indirect
	golang.org/x/mod v0.33.0 // indirect
	golang.org/x/sync v0.19.0 // indirect
	modernc.org/gc/v2 v2.6.5 // indirect
	modernc.org/gc/v3 v3.1.2 // indirect
	modernc.org/opt v0.1.4 // indirect
	modernc.org/sortutil v1.2.1 // indirect
	modernc.org/strutil v1.2.1 // indirect
	modernc.org/token v1.1.0 // indirect
)
