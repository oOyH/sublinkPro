module gitlab.com/yawning/bsaes.git

go 1.12

require golang.org/x/sys v0.0.0-20190804053845-51ab0e2deafa
