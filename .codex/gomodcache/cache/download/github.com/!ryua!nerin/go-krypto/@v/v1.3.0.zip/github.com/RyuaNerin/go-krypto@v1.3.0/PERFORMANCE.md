# go-krypto Performance

TODO
