module github.com/metacubex/mlkem

go 1.20

require golang.org/x/crypto v0.33.0

require golang.org/x/sys v0.30.0 // indirect
