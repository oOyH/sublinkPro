//go:build go1.25

package self_test

import "github.com/metacubex/tls"

func getCurveID(connState tls.ConnectionState) tls.CurveID {
	return connState.CurveID
}
