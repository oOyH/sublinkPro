#!/bin/bash

# Copyright (C) 2024  mieru authors
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

# Make sure this script has executable permission:
# git update-index --chmod=+x <file>

export PATH_PREFIX="test/deploy/externalconnect"

# Load test library.
source ./${PATH_PREFIX}/libtest.sh

# Update mieru server with UDP config.
./bin/mita apply config ${PATH_PREFIX}/server_udp.json
if [[ "$?" -ne 0 ]]; then
    echo "command 'mita apply config server_udp.json' failed"
    exit 1
fi
echo "mieru server config:"
./bin/mita describe config

# Start mieru server proxy.
./bin/mita start
if [[ "$?" -ne 0 ]]; then
    echo "command 'mita start' failed"
    exit 1
fi

# Update mieru client with UDP config.
./bin/mieru apply config ${PATH_PREFIX}/client_udp.json
if [[ "$?" -ne 0 ]]; then
    echo "command 'mieru apply config client_udp.json' failed"
    exit 1
fi
echo "mieru client config:"
./bin/mieru describe config

# Start mieru client.
./bin/mieru start
if [[ "$?" -ne 0 ]]; then
    echo "command 'mieru start' failed"
    exit 1
fi

# Start testing.
sleep 2
run_external_connect_test
if [[ "$?" -ne 0 ]]; then
    print_mieru_client_log
    sleep 1
    print_mieru_client_metrics
    sleep 1
    print_mieru_server_metrics
    exit 1
fi

# Stop mieru client.
./bin/mieru stop
if [[ "$?" -ne 0 ]]; then
    echo "command 'mieru stop' failed"
    exit 1
fi
sleep 1

# Stop mieru server proxy.
./bin/mita stop
if [[ "$?" -ne 0 ]]; then
    echo "command 'mita stop' failed"
    exit 1
fi
sleep 1

print_mieru_client_log
delete_mieru_client_log
sleep 1
